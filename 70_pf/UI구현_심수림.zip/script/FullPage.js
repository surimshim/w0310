new fullpage('#fullpage', {
    autoScrolling: true,
    navigation: true,
    anchors: ['firstPage', 'secondPage', 'thirdPage', 'fourthPage'],
    navigationTooltips: ['First', 'Second', 'Third', 'Fourth'],
    showActiveTooltip: true,
});